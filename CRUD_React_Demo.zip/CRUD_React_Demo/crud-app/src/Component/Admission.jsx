import { Box, Typography, makeStyles } from '@material-ui/core';


const useStyles = makeStyles({
    component: {
        margin: 50,
        '& > *': {
            marginTop: 50
        }
    },
    image: {
        width: '50%',
        height: '50%'
    }
})

const AdmissionComp = () => {
    const classes = useStyles();
    return (
        <Box className={classes.component}>
            <Typography variant="h2">Silver Oak of University</Typography>
            <Typography variant="h4">The Silver Oak University is known for its “Out of Box” initiatives and emphasis on “Education to Innovation”. Silver Oak College of Technology consists of two engineering colleges namely, Silver Oak College of Engineering & Technology (more commonly known as SOCET) established in year 2009 and Aditya Silver Oak Institute of Technology (more commonly known as ASOIT) established in year 2014. Both institutes are AICTE Approved. Today it is one of the most sought after institutes for pursuing education in engineering & technology across the state of Gujarat. Both the colleges offers Diploma Engineering, B.Tech, & M.Tech programs 12 different disciplines of engineering which are employment oriented and with updated curriculum as per the requirements of present Industries in hard and soft branches.</Typography>
        </Box>
    )
}

export default AdmissionComp;