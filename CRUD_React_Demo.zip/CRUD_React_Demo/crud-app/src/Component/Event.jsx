import { Box, Typography, makeStyles } from '@material-ui/core';


const useStyles = makeStyles({
    component: {
        margin: 50,
        '& > *': {
            marginTop: 50
        }
    },
    image: {
        width: '50%',
        height: '50%'
    }
})

const EventComp = () => {
    const classes = useStyles();
    return (
        <Box className={classes.component}>
            <Typography variant="h2">Events</Typography>
            <Typography variant="h4">“Act is always judged with the motto it has.”
            Google Cloud Technology, Silver Oak University organised and managed by Department of Computer Engineering at Silver Oak College of Engineering and Technology with a motive to strive and stride towards excellence had recently hosted the #GoogleCloudReady Facilitator Program in association with SOU IEEE SB. The program was launched by Google Cloud wherein a few institutions across India were approached to be a collaborator and host this program. In this program, students got an opportunity to work on various lab technologies and procure hands-on training on the platform of Qwiklabs, which included the different concepts of cloud technology from Cloud Architecture to Application Development and Machine Learning to BigData with Cloud Technology.</Typography>
        </Box>
    )
}

export default EventComp;