import { Box, Typography, makeStyles } from '@material-ui/core';


const useStyles = makeStyles({
    component: {
        margin: 50,
        '& > *': {
            marginTop: 50
        }
    },
    image: {
        width: '50%',
        height: '50%'
    }
})

const AboutComp = () => {
    const classes = useStyles();
    return (
        <Box className={classes.component}>
            <Typography variant="h2">Vision of University</Typography>
            <Typography variant="h4">A leading Engineering & Technological Institution to be benchmarked with design-centric Research & bonafide Innovation.
            The Institution to provide Competent Leaders with Global Perspective.
            The Institution to perpetuate academic excellence and promote knowledge-based spectrum.
            The Institution to enhance practical relevance of Research & Development.
            The Institution to contribute substantially to the rapid industrial and economic growth of the nation.</Typography>
            <Typography variant="h2">Mission of University</Typography>
            <Typography variant="h4">The Institution to provide education par excellence and thoroughly professional training with its state-of-the-art facilities.
            The Institution to create an environment for students where they always explore, discover and apply.
            The Institution to craft, establish and sustain the futuristic infrastructure such as Technology Incubation Center, Software Development Park and e-Training Facility.
            The institution to build a creative bond with industries, societies, intellectual bodies that share same myopic goals and broader objectives and responsibilities.
            The institution to establish an academic collaboration with reputed International institutions.
            The institution to always believe in improving positive work culture and acting upon the code of conduct.</Typography>
            <Typography variant="h2">Objective of University</Typography>
            <Typography variant="h4">To provide world class education focused on areas across the value chain of the green energy and environmental science industry.
            To achieve and sustain academic excellence in an environment that represents an unique commitment to innovation, quality and service.
            To address the challenges of the industry and encourage innovation through cutting-edge research and collaboration with industry.
            To serve the global community by producing educated and well trained individuals.</Typography>
        </Box>
    )
}

export default AboutComp;