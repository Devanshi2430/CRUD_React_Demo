import { Box, Typography, makeStyles } from '@material-ui/core';


const useStyles = makeStyles({
    component: {
        margin: 50,
        '& > *': {
            marginTop: 50
        }
    },
    image: {
        width: '50%',
        height: '50%'
    }
})

const WelcomeComp = () => {
    const classes = useStyles();
    return (
        <Box className={classes.component}>
            <Typography variant="h4">Silver Oak University(SOU) is premier private university carrying forward the legacy of Silver Oak Group of Institutes.
            As a reflection to its motto, “Gyanam Param Bhushanam” meaning Knowledge is the highest virtue, SOU delivers engaging learning experience through futuristic curriculum, advanced technological interface, eminent faculty, industry academia bonding, career planning and counseling and ample career opportunities.
            Recently announced as a State Private University (under Gujarat Private Universities Act, 2009) Silver Oak was established in 2009 as an affiliated college and gradually grew into Silver Oak Group of Institutes.
            It started with 240 students and has grown into one of the largest campuses for Engineering College and a plethora of courses that houses more than 15000 students.</Typography>
        </Box>
    )
}

export default WelcomeComp;